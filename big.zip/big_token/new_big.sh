#!/bin/bash
clear
date

node new_big.js
sleep 100
# rerun myself
exec $0
